﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proje_telefonmarkamodel_.View
{
    public partial class frmAnaSayfa : Form
    {
        public frmAnaSayfa()
        {
            InitializeComponent();
            markaEkleToolStripMenuItem.Click += MarkaEkleToolStripMenuItem_Click;
            modelEkleToolStripMenuItem.Click += ModelEkleToolStripMenuItem_Click;
            ListeleToolStripMenuItem.Click += ListeleToolStripMenuItem_Click;
        }

        private void ListeleToolStripMenuItem_Click(object? sender, EventArgs e)
        {
            FormGetir(new frmListele());
        }

        private void ModelEkleToolStripMenuItem_Click(object? sender, EventArgs e)
        {
            FormGetir(new frmModelEkle());
        }

        private void MarkaEkleToolStripMenuItem_Click(object? sender, EventArgs e)
        {
            FormGetir(new frmMarkaEkle());
        }

        private void FormGetir(Form form)
        {
            panel1.Controls.Clear();
            form.TopLevel=false;
            form.FormBorderStyle=FormBorderStyle.None;
            form.Dock=DockStyle.Fill;
            panel1.Controls.Add(form);
            form.Show();
        }
    }
}
