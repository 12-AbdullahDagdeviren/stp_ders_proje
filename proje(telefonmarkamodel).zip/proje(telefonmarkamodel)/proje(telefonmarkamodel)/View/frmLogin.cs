﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proje_telefonmarkamodel_.View
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            // TextBox lardaki, değerleri alıyoruz
            string kullaniciAdi = textBox3.Text.Trim();
            string sifre = textBox4.Text.Trim();

            // Kullanıcı adı ve şifre boş mu kontrol ediyoruz
            if (string.IsNullOrEmpty(kullaniciAdi) || string.IsNullOrEmpty(sifre))
            {
                MessageBox.Show("Kullanıcı adı ve şifre boş olamaz!", "hata",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
                //Örnek sabit kullanıcı adı ve şifre (sadece demo amaçlı)
                //Gerçek projede bu kısım veritabanı sorgusuna dayalı olabilir

             if(kullaniciAdi == "admin" && sifre == "12345")
             {
                 MessageBox.Show("Giriş başarılı! hoş geldiniz.", "Bilgi",
                                 MessageBoxButtons.OK, MessageBoxIcon.Information);
                 //Ana formu açıp login formunu kapatıyoruz 
                 frmAnaSayfa mainForm = new frmAnaSayfa();
                 mainForm.Show();

                 this.Hide();
             }
             else
             {
                 // Hatalı giriş uyarısı
                 MessageBox.Show("Kullanıcı adı veya şifre hatalı!", "hata",
                                  MessageBoxButtons.OK, MessageBoxIcon.Error);
             }
            
            InitializeComponent();
        }
    }
}
