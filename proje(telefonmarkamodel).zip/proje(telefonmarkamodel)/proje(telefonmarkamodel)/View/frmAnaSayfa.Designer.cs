﻿namespace proje_telefonmarkamodel_.View
{
    partial class frmAnaSayfa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAnaSayfa));
            ımageList1 = new ImageList(components);
            ımageList2 = new ImageList(components);
            menuStrip1 = new MenuStrip();
            ekleToolStripMenuItem = new ToolStripMenuItem();
            markaEkleToolStripMenuItem = new ToolStripMenuItem();
            modelEkleToolStripMenuItem = new ToolStripMenuItem();
            ListeleToolStripMenuItem = new ToolStripMenuItem();
            panel1 = new Panel();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // ımageList1
            // 
            ımageList1.ColorDepth = ColorDepth.Depth32Bit;
            ımageList1.ImageStream = (ImageListStreamer)resources.GetObject("ımageList1.ImageStream");
            ımageList1.TransparentColor = Color.Transparent;
            ımageList1.Images.SetKeyName(0, "AddIcon.png");
            // 
            // ımageList2
            // 
            ımageList2.ColorDepth = ColorDepth.Depth32Bit;
            ımageList2.ImageStream = (ImageListStreamer)resources.GetObject("ımageList2.ImageStream");
            ımageList2.TransparentColor = Color.Transparent;
            ımageList2.Images.SetKeyName(0, "clear.png");
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { ekleToolStripMenuItem, ListeleToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(731, 24);
            menuStrip1.TabIndex = 5;
            menuStrip1.Text = "menuStrip1";
            // 
            // ekleToolStripMenuItem
            // 
            ekleToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { markaEkleToolStripMenuItem, modelEkleToolStripMenuItem });
            ekleToolStripMenuItem.Name = "ekleToolStripMenuItem";
            ekleToolStripMenuItem.Size = new Size(44, 20);
            ekleToolStripMenuItem.Text = "EKLE";
            // 
            // markaEkleToolStripMenuItem
            // 
            markaEkleToolStripMenuItem.Name = "markaEkleToolStripMenuItem";
            markaEkleToolStripMenuItem.Size = new Size(180, 22);
            markaEkleToolStripMenuItem.Text = "MARKA EKLE";
            // 
            // modelEkleToolStripMenuItem
            // 
            modelEkleToolStripMenuItem.Name = "modelEkleToolStripMenuItem";
            modelEkleToolStripMenuItem.Size = new Size(180, 22);
            modelEkleToolStripMenuItem.Text = "MODEL EKLE";
            // 
            // ListeleToolStripMenuItem
            // 
            ListeleToolStripMenuItem.Name = "ListeleToolStripMenuItem";
            ListeleToolStripMenuItem.Size = new Size(59, 20);
            ListeleToolStripMenuItem.Text = "LİSTELE";
            // 
            // panel1
            // 
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 24);
            panel1.Name = "panel1";
            panel1.Size = new Size(731, 469);
            panel1.TabIndex = 6;
            // 
            // frmAnaSayfa
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(731, 493);
            Controls.Add(panel1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "frmAnaSayfa";
            Text = "frmAnaSayfa";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private MenuStrip menuStrip1;
        private ImageList ımageList1;
        private ImageList ımageList2;
        private ToolStripMenuItem ekleToolStripMenuItem;
        private ToolStripMenuItem ListeleToolStripMenuItem;
        private ToolStripMenuItem markaEkleToolStripMenuItem;
        private ToolStripMenuItem modelEkleToolStripMenuItem;
        private Panel panel1;
    }
}