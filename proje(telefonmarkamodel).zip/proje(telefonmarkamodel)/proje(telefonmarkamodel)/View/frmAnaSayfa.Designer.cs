﻿namespace proje_telefonmarkamodel_.View
{
    partial class frmAnaSayfa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAnaSayfa));
            pictureBox1 = new PictureBox();
            label1 = new Label();
            textBox1 = new TextBox();
            button1 = new Button();
            ımageList1 = new ImageList(components);
            button2 = new Button();
            ımageList2 = new ImageList(components);
            menuStrip1 = new MenuStrip();
            eKLEToolStripMenuItem = new ToolStripMenuItem();
            lİSTELEToolStripMenuItem = new ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(12, 27);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(287, 411);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label1.Location = new Point(326, 136);
            label1.Name = "label1";
            label1.Size = new Size(89, 20);
            label1.TabIndex = 1;
            label1.Text = "Marka Adı :";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(421, 133);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(152, 23);
            textBox1.TabIndex = 2;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            button1.ImageAlign = ContentAlignment.MiddleRight;
            button1.ImageKey = "AddIcon.png";
            button1.ImageList = ımageList1;
            button1.Location = new Point(345, 240);
            button1.Name = "button1";
            button1.Size = new Size(105, 33);
            button1.TabIndex = 3;
            button1.Text = "LİSTELE";
            button1.UseVisualStyleBackColor = true;
            // 
            // ımageList1
            // 
            ımageList1.ColorDepth = ColorDepth.Depth32Bit;
            ımageList1.ImageStream = (ImageListStreamer)resources.GetObject("ımageList1.ImageStream");
            ımageList1.TransparentColor = Color.Transparent;
            ımageList1.Images.SetKeyName(0, "AddIcon.png");
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            button2.ImageAlign = ContentAlignment.MiddleRight;
            button2.ImageKey = "clear.png";
            button2.ImageList = ımageList2;
            button2.Location = new Point(483, 240);
            button2.Name = "button2";
            button2.Size = new Size(105, 33);
            button2.TabIndex = 4;
            button2.Text = "TEMİZLE";
            button2.UseVisualStyleBackColor = true;
            // 
            // ımageList2
            // 
            ımageList2.ColorDepth = ColorDepth.Depth32Bit;
            ımageList2.ImageStream = (ImageListStreamer)resources.GetObject("ımageList2.ImageStream");
            ımageList2.TransparentColor = Color.Transparent;
            ımageList2.Images.SetKeyName(0, "clear.png");
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { eKLEToolStripMenuItem, lİSTELEToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(638, 24);
            menuStrip1.TabIndex = 5;
            menuStrip1.Text = "menuStrip1";
            // 
            // eKLEToolStripMenuItem
            // 
            eKLEToolStripMenuItem.Name = "eKLEToolStripMenuItem";
            eKLEToolStripMenuItem.Size = new Size(44, 20);
            eKLEToolStripMenuItem.Text = "EKLE";
            // 
            // lİSTELEToolStripMenuItem
            // 
            lİSTELEToolStripMenuItem.Name = "lİSTELEToolStripMenuItem";
            lİSTELEToolStripMenuItem.Size = new Size(59, 20);
            lİSTELEToolStripMenuItem.Text = "LİSTELE";
            // 
            // frmAnaSayfa
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(638, 450);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "frmAnaSayfa";
            Text = "frmAnaSayfa";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label1;
        private TextBox textBox1;
        private Button button1;
        private Button button2;
        private MenuStrip menuStrip1;
        private ImageList ımageList1;
        private ImageList ımageList2;
        private ToolStripMenuItem eKLEToolStripMenuItem;
        private ToolStripMenuItem lİSTELEToolStripMenuItem;
    }
}