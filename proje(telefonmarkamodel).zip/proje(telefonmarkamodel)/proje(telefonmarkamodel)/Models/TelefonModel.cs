﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proje_telefonmarkamodel_.Models
{
    public class TelefonModel
    {
        public int Id { get; set; }
        public string ModelAdi { get; set; }
        public decimal Fiyat {  get; set; }
        public double EkranBoyutu { get; set; }
        public int RAMMiktari {  get; set; }
        public int DahiliHafıza { get; set; }
        public int PilKapasitesi { get; set; }

        [ForeignKey("Marka")]
        public int MarkaId { get; set; }
        public virtual Marka Marka { get; set; }
    }
}
