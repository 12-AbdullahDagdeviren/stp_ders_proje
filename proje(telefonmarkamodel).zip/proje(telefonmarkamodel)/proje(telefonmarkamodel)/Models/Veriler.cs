﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using proje_telefonmarkamodel_.Models;

namespace proje_telefonmarkamodel_.Models
{
    public static class Veriler
    {
        public static object Context { get; }

        public static AppDbContext = new AppDbContext();

        static Veriler()
        {
            Context.Database.Migrate();

            if (!Context.Markalar.Any())
            {
                OrnekVeri();
            }
        }

        private static void OrnekVeri()
        {
            Context.Markalar.Add(new Marka())
                {
                    MarkaAdi = "Samsung",
                    Modeller = new List<Model>
                    {
                        new Model()
                        {
                            ModelAdi="Galaxy s10+ Plus",
                            Fiyat=9699,
                            EkranBoyutu=6.4,
                            RAMMiktari=8,
                            DahiliHafıza=8,
                            PilKapasitesi=4100
                        },
                        new Model() {
                            ModelAdi"Galaxy s20+ Plus",
                            Fiyat=19699,
                            EkranBoyutu=6.4,
                            RAMMiktari=8,
                            DahiliHafıza=16,
                            PilKapasitesi=5100
                        },

                    }
                });
            Context.SaveChanges();
        }
    }
}
