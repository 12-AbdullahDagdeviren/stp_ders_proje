﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using proje_telefonmarkamodel_.Models;
using System.Drawing.Text;

namespace proje_telefonmarkamodel_.Models
{
    public static class Veriler
    {

        public static AppDbContext Context = new AppDbContext();

        static Veriler()
        {
            Context.Database.Migrate();

            if (!Context.Markalar.Any())
            {
                OrnekVeri();
            }
        }

        private static void OrnekVeri()
        {
            Context.Markalar.Add(
                new Marka()
                {
                    MarkaAdi = "Samsung",
                    Modeller = new List<TelefonModel>
                    {
                        new TelefonModel()
                        {
                            ModelAdi="Galaxy s10+ Plus",
                            Fiyat=9699,
                            EkranBoyutu=6.4,
                            RAMMiktari=8,
                            DahiliHafıza=8,
                            PilKapasitesi=4100
                        },
                        new TelefonModel() 
                        {
                            ModelAdi="Galaxy s20+ Plus",
                            Fiyat=19699,
                            EkranBoyutu=6.4,
                            RAMMiktari=8,
                            DahiliHafıza=16,
                            PilKapasitesi=5100
                        },

                    }
                });
            Context.SaveChanges();
        }
    }
}
