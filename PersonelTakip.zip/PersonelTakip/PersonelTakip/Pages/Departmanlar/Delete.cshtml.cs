﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using PersonelTakip.Data;
using PersonelTakip.Models;

namespace PersonelTakip.Pages.Departmanlar
{
    public class DeleteModel : PageModel
    {
        private readonly PersonelTakip.Data.AppDbContext _context;

        public DeleteModel(PersonelTakip.Data.AppDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Departman Departman { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var departman = await _context.Departmanlar.FirstOrDefaultAsync(m => m.Id == id);

            if (departman is not null)
            {
                Departman = departman;

                return Page();
            }

            return NotFound();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var departman = await _context.Departmanlar.FindAsync(id);
            if (departman != null)
            {
                Departman = departman;
                _context.Departmanlar.Remove(Departman);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
