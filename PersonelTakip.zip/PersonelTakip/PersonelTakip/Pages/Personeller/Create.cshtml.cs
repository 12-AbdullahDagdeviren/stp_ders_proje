﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using PersonelTakip.Data;
using PersonelTakip.Models;

namespace PersonelTakip.Pages.Personeller
{
    public class CreateModel : PageModel
    {
        private readonly PersonelTakip.Data.AppDbContext _context;

        public CreateModel(PersonelTakip.Data.AppDbContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
        ViewData["DepartmanId"] = new SelectList(_context.Departmanlar, "Id", "Adi");
            return Page();
        }

        [BindProperty]
        public Personel Personel { get; set; } = default!;

        // For more information, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Personeller.Add(Personel);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
