﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using PersonelTakip.Data;
using PersonelTakip.Models;

namespace PersonelTakip.Pages.Personeller
{
    public class DeleteModel : PageModel
    {
        private readonly PersonelTakip.Data.AppDbContext _context;

        public DeleteModel(PersonelTakip.Data.AppDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Personel Personel { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var personel = await _context.Personeller.FirstOrDefaultAsync(m => m.Id == id);

            if (personel is not null)
            {
                Personel = personel;

                return Page();
            }

            return NotFound();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var personel = await _context.Personeller.FindAsync(id);
            if (personel != null)
            {
                Personel = personel;
                _context.Personeller.Remove(Personel);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
