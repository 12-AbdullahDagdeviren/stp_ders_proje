﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using PersonelTakip.Data;
using PersonelTakip.Models;

namespace PersonelTakip.Pages.Personeller
{
    public class IndexModel : PageModel
    {
        private readonly PersonelTakip.Data.AppDbContext _context;

        public IndexModel(PersonelTakip.Data.AppDbContext context)
        {
            _context = context;
        }

        public IList<Personel> Personel { get;set; } = default!;

        public async Task OnGetAsync()
        {
            Personel = await _context.Personeller
                .Include(p => p.Departman).ToListAsync();
        }
    }
}
