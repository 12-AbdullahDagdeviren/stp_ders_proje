﻿using Microsoft.EntityFrameworkCore;
using PersonelTakip.Models;

namespace PersonelTakip.Data
{
    public class AppDbContext:DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Departman> Departmanlar { get; set; }
        public DbSet<Personel> Personeller { get; set; }
    }
}
