﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PersonelTakip.Models
{
    public class Personel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Ad Soyad zorunludur.")]
        [Display(Name = "Ad Soyad")]
        public string AdSoyad { get; set; }

        [EmailAddress]
        public string Email { get; set; }

        [Range(0, 100000, ErrorMessage = "Maaş 0 ile 100.000 arasında olmalıdır.")]
        public decimal Maas { get; set; }

        [Display(Name = "Departman")]
        public int DepartmanId { get; set; }

        [Range(1, int.MaxValue, ErrorMessage = "Departman seçimi zorunludur.")]
        [ForeignKey("DepartmanId")]
        public Departman? Departman { get; set; }
    }
}
