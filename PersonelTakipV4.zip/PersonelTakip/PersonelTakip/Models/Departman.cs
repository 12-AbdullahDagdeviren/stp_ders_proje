﻿using System.Collections;
using System.ComponentModel.DataAnnotations;

namespace PersonelTakip.Models
{
    public class Departman
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Departman adı zorunludur.")]
        public string Adi { get; set; }

        public ICollection<Personel>? Personeller { get; set; }
    }
}
